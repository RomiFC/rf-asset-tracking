NANO_CARRIER_450-0070-01_REVX3

The board outline is included on all gerbers.